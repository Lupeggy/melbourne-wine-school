console.log('Node.js is working!');
console.log('Node.js version:', process.version);
