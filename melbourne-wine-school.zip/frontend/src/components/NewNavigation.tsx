'use client';

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useRef, useEffect } from "react";
import { 
  Menu, 
  X, 
  ChevronDown, 
  Phone, 
  Mail, 
  ShoppingCart, 
  User, 
  Wine, 
  Users, 
  Store, 
  Calendar, 
  Heart,
  LogIn,
  UserPlus
} from 'lucide-react';

type NavItem = {
  name: string;
  href: string;
  icon?: React.ReactNode;
  subItems?: {
    name: string;
    href: string;
    description?: string;
  }[];
};

const NewNavigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const pathname = usePathname();
  const navRef = useRef<HTMLDivElement>(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (navRef.current && !navRef.current.contains(event.target as Node)) {
        setIsCartOpen(false);
        setIsProfileOpen(false);
        setOpenDropdown(null);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleDropdown = (name: string) => {
    setOpenDropdown(openDropdown === name ? null : name);
  };

  const toggleLike = () => {
    setIsLiked(!isLiked);
  };

  const toggleCart = () => {
    setIsCartOpen(!isCartOpen);
    setIsProfileOpen(false);
  };

  const toggleProfile = () => {
    setIsProfileOpen(!isProfileOpen);
    setIsCartOpen(false);
  };

  const handleLogin = () => {
    // TODO: Implement login logic
    setIsAuthenticated(true);
    setIsProfileOpen(false);
  };

  const handleLogout = () => {
    // TODO: Implement logout logic
    setIsAuthenticated(false);
    setIsProfileOpen(false);
  };

  const closeAll = () => {
    setIsOpen(false);
    setIsCartOpen(false);
    setIsProfileOpen(false);
    setOpenDropdown(null);
  };

  const navItems: NavItem[] = [
    { 
      name: "Courses", 
      href: "/courses",
      subItems: [
        { 
          name: "WSET Courses", 
          href: "/courses/wset",
          description: "Internationally recognized wine qualifications"
        },
        { 
          name: "Other Wine Courses", 
          href: "/courses/other",
          description: "Specialized and casual wine education"
        },
        { 
          name: "Tasting Workshops", 
          href: "/courses/workshops",
          description: "Interactive wine tasting experiences"
        },
      ]
    },
    { 
      name: "Wine Club", 
      href: "/wine-club"
    },
    { 
      name: "Marketplace", 
      href: "/marketplace"
    },
    { 
      name: "Events", 
      href: "/events"
    }
  ];

  const isActive = (item: NavItem) => {
    if (pathname === item.href) return true;
    if (item.subItems) {
      return item.subItems.some(subItem => pathname === subItem.href);
    }
    return false;
  };

  return (
    <div className="bg-white shadow-sm sticky top-0 z-50" ref={navRef}>
      {/* Top Bar - Logo, Search, Support */}
      <div className="border-b border-gray-100">
        <div className="container mx-auto px-4 py-3">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            {/* Logo */}
            <div className="flex-shrink-0">
              <Link href="/" className="text-2xl font-bold text-primary-900 flex items-center">
                <Wine className="h-6 w-6 mr-2" />
                Melbourne Wine School
              </Link>
            </div>
            
            {/* Search Bar */}
            <div className="w-full md:w-1/3">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search courses, events, and more..."
                  className="w-full px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent text-sm"
                />
                <button className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-primary-600">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                </button>
              </div>
            </div>
            
            {/* Support Links */}
            <div className="flex items-center space-x-6">
              <a href="/about" className="text-gray-700 hover:text-primary-600 text-sm font-medium transition-colors">
                About Us
              </a>
              <a href="/support" className="text-gray-700 hover:text-primary-600 text-sm font-medium transition-colors">
                Support
              </a>
              <a href="tel:+61396541055" className="text-gray-700 hover:text-primary-600 text-sm font-medium transition-colors flex items-center">
                <Phone className="h-4 w-4 mr-1" />
                +61 3 9654 1055
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation - Second Row */}
      <div className="bg-white border-b border-gray-100">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            {/* Main Navigation Links */}
            <div className="hidden md:flex space-x-8">
              {navItems.map((item) => (
                <div key={item.name} className="relative group">
                  {item.subItems ? (
                    <>
                      <button
                        onClick={() => toggleDropdown(item.name)}
                        className={`flex items-center px-1 pt-1 pb-2 text-sm font-medium ${
                          isActive(item)
                            ? 'text-primary-600 border-b-2 border-primary-600'
                            : 'text-gray-700 hover:text-gray-900 hover:border-b-2 hover:border-gray-300'
                        }`}
                      >
                        {item.name}
                        <ChevronDown className={`ml-1 h-4 w-4 transition-transform ${
                          openDropdown === item.name ? 'transform rotate-180' : ''
                        }`} />
                      </button>
                      
                      {/* Dropdown Menu */}
                      {openDropdown === item.name && (
                        <div className="absolute left-0 mt-1 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50">
                          <div className="py-1">
                            {item.subItems.map((subItem) => (
                              <Link
                                key={subItem.href}
                                href={subItem.href}
                                className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-primary-700"
                                onClick={closeAll}
                              >
                                {subItem.name}
                                {subItem.description && (
                                  <p className="text-xs text-gray-500 mt-1">{subItem.description}</p>
                                )}
                              </Link>
                            ))}
                          </div>
                        </div>
                      )}
                    </>
                  ) : (
                    <Link
                      href={item.href}
                      className={`inline-flex items-center px-1 pt-1 pb-2 text-sm font-medium ${
                        pathname === item.href
                          ? 'text-primary-600 border-b-2 border-primary-600'
                          : 'text-gray-700 hover:text-gray-900 hover:border-b-2 hover:border-gray-300'
                      }`}
                      onClick={closeAll}
                    >
                      {item.name}
                    </Link>
                  )}
                </div>
              ))}
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-gray-900 hover:bg-gray-100 focus:outline-none"
                aria-expanded="false"
              >
                <span className="sr-only">Open main menu</span>
                {isOpen ? (
                  <X className="block h-6 w-6" aria-hidden="true" />
                ) : (
                  <Menu className="block h-6 w-6" aria-hidden="true" />
                )}
              </button>
            </div>

            {/* Right side - Auth and Cart */}
            <div className="flex items-center space-x-4">
              {/* Like Button */}
              <button 
                onClick={toggleLike}
                className="p-2 text-gray-500 hover:text-primary-600 transition-colors relative"
                aria-label="Wishlist"
              >
                <Heart 
                  className={`h-5 w-5 ${isLiked ? 'fill-red-500 text-red-500' : 'text-gray-500'}`} 
                />
                <span className="absolute -top-1 -right-1 bg-primary-600 text-white text-xs font-bold rounded-full h-4 w-4 flex items-center justify-center text-[10px]">0</span>
              </button>

              {/* Cart */}
              <div className="relative">
                <button 
                  onClick={toggleCart}
                  className="p-2 text-gray-500 hover:text-primary-600 transition-colors relative"
                  aria-label="Shopping Cart"
                >
                  <ShoppingCart className="h-5 w-5" />
                  <span className="absolute -top-1 -right-1 bg-primary-600 text-white text-xs font-bold rounded-full h-4 w-4 flex items-center justify-center text-[10px]">0</span>
                </button>
                {isCartOpen && (
                  <div className="absolute right-0 mt-2 w-72 bg-white rounded-md shadow-lg py-1 z-50 border border-gray-200">
                    <div className="px-4 py-3 border-b">
                      <p className="text-sm text-gray-700">Your cart is empty</p>
                    </div>
                    <div className="px-4 py-2">
                      <a href="/cart" className="block w-full text-center bg-primary-600 text-white px-4 py-2 rounded hover:bg-primary-700 transition-colors">
                        View Cart
                      </a>
                    </div>
                  </div>
                )}
              </div>

              {/* User Profile */}
              <div className="relative">
                <button 
                  onClick={toggleProfile}
                  className="flex items-center space-x-1 text-sm font-medium text-gray-700 hover:text-primary-600 transition-colors"
                  aria-label="User Profile"
                >
                  <User className="h-5 w-5" />
                  <span>Account</span>
                  <ChevronDown className={`h-4 w-4 transition-transform ${isProfileOpen ? 'transform rotate-180' : ''}`} />
                </button>
                
                {isProfileOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-md shadow-lg py-1 z-50 border border-gray-200">
                    {isAuthenticated ? (
                      <>
                        <div className="px-4 py-3 border-b">
                          <p className="text-sm font-medium text-gray-900">Welcome back!</p>
                          <p className="text-xs text-gray-500">user@example.com</p>
                        </div>
                        <a href="/dashboard" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                          My Dashboard
                        </a>
                        <a href="/orders" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                          My Orders
                        </a>
                        <a href="/wishlist" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                          Wishlist
                        </a>
                        <div className="border-t border-gray-100"></div>
                        <button 
                          onClick={handleLogout}
                          className="block w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-gray-50"
                        >
                          Sign Out
                        </button>
                      </>
                    ) : (
                      <>
                        <div className="px-4 py-3 border-b">
                          <p className="text-sm text-gray-700">Welcome to Melbourne Wine School</p>
                        </div>
                        <a 
                          href="/login" 
                          className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
                          onClick={(e) => {
                            e.preventDefault();
                            handleLogin();
                          }}
                        >
                          <LogIn className="h-4 w-4 mr-2" />
                          Sign In
                        </a>
                        <a 
                          href="/signup" 
                          className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
                          onClick={(e) => {
                            e.preventDefault();
                            handleLogin(); // For demo, just log in
                          }}
                        >
                          <UserPlus className="h-4 w-4 mr-2" />
                          Create Account
                        </a>
                      </>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`md:hidden ${isOpen ? 'block' : 'hidden'}`}>
        <div className="pt-2 pb-3 space-y-1">
          {navItems.map((item) => (
            <div key={item.name} className="px-2 pt-2 pb-3 space-y-1">
              {item.subItems ? (
                <div>
                  <button
                    onClick={() => toggleDropdown(item.name)}
                    className="w-full flex justify-between items-center px-3 py-2 text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50 rounded-md"
                  >
                    <div className="flex items-center">
                      {item.icon}
                      <span className="ml-3">{item.name}</span>
                    </div>
                    <ChevronDown className={`h-5 w-5 transform transition-transform ${
                      openDropdown === item.name ? 'rotate-180' : ''
                    }`} />
                  </button>
                  <div className={`${openDropdown === item.name ? 'block' : 'hidden'} mt-2 space-y-1`}>
                    {item.subItems.map((subItem) => (
                      <Link
                        key={subItem.href}
                        href={subItem.href}
                        className="group w-full flex items-center pl-11 pr-2 py-2 text-sm font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-md"
                        onClick={closeAll}
                      >
                        {subItem.name}
                        {subItem.description && (
                          <span className="ml-2 text-xs text-gray-500 group-hover:text-gray-700">
                            {subItem.description}
                          </span>
                        )}
                      </Link>
                    ))}
                  </div>
                </div>
              ) : (
                <Link
                  href={item.href}
                  className="flex items-center px-3 py-2 text-base font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50 rounded-md"
                  onClick={closeAll}
                >
                  {item.icon}
                  <span className="ml-3">{item.name}</span>
                </Link>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default NewNavigation;
