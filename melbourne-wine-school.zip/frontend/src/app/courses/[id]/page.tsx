import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';

const courses = {
  beginner: {
    id: 'beginner',
    title: 'Wine Fundamentals',
    description: 'Learn the basics of wine tasting, grape varieties, and food pairing in this introductory course.',
    longDescription: 'This comprehensive course is designed for wine enthusiasts who want to build a solid foundation in wine knowledge. Over four weeks, you\'ll explore the major wine regions of the world, understand different grape varieties, and learn professional tasting techniques.',
    duration: '4 weeks',
    price: 199,
    image: '/wine-tasting.jpg',
    level: 'Beginner',
    schedule: [
      'Week 1: Introduction to Wine Tasting',
      'Week 2: Major Grape Varieties',
      'Week 3: Old World vs New World Wines',
      'Week 4: Food and Wine Pairing Basics'
    ],
    whatYoullLearn: [
      'How to taste wine like a professional',
      'Key characteristics of major grape varieties',
      'Understanding wine labels and terminology',
      'Basic food and wine pairing principles',
      'Wine serving and storage best practices'
    ]
  },
  // Add other courses with similar structure
};

export default function CourseDetailPage({ params }: { params: { id: string } }) {
  const course = courses[params.id as keyof typeof courses];

  if (!course) {
    notFound();
  }

  return (
    <div className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:flex lg:items-center lg:justify-between">
          <div className="lg:w-1/2">
            <span className="inline-block px-3 py-1 text-sm font-semibold text-purple-800 bg-purple-100 rounded-full">
              {course.level} Level
            </span>
            <h1 className="mt-4 text-4xl font-extrabold text-gray-900 sm:text-5xl">
              {course.title}
            </h1>
            <p className="mt-4 text-xl text-gray-600">
              {course.description}
            </p>
            <div className="mt-6">
              <div className="flex items-center text-gray-700">
                <svg className="h-5 w-5 text-purple-500" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                </svg>
                <span className="ml-2">{course.duration}</span>
              </div>
              <div className="mt-2 flex items-center text-gray-700">
                <svg className="h-5 w-5 text-purple-500" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z" />
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z" clipRule="evenodd" />
                </svg>
                <span className="ml-2">${course.price}</span>
              </div>
            </div>
            <div className="mt-8">
              <button className="w-full md:w-auto bg-purple-600 text-white px-8 py-3 rounded-md font-medium hover:bg-purple-700 transition-colors">
                Enroll Now
              </button>
              <p className="mt-2 text-sm text-gray-500">
                Next session starts on June 15, 2023
              </p>
            </div>
          </div>
          <div className="mt-10 lg:mt-0 lg:ml-10 lg:flex-shrink-0">
            <div className="relative h-64 w-full rounded-lg overflow-hidden sm:h-72 md:h-96 lg:w-96">
              <Image
                src={course.image}
                alt={course.title}
                layout="fill"
                className="object-cover"
              />
            </div>
          </div>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold text-gray-900">About This Course</h2>
            <p className="mt-4 text-gray-600">
              {course.longDescription}
            </p>
            
            <h3 className="mt-8 text-xl font-semibold text-gray-900">What You'll Learn</h3>
            <ul className="mt-4 space-y-2">
              {course.whatYoullLearn?.map((item, index) => (
                <li key={index} className="flex items-start">
                  <svg className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span>{item}</span>
                </li>
              ))}
            </ul>

            <h3 className="mt-8 text-xl font-semibold text-gray-900">Course Schedule</h3>
            <ul className="mt-4 space-y-2">
              {course.schedule?.map((item, index) => (
                <li key={index} className="flex items-start">
                  <svg className="h-5 w-5 text-purple-500 mr-2 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
                  </svg>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-gray-900">Course Details</h3>
              <div className="mt-4 space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Duration</h4>
                  <p className="mt-1 text-gray-900">{course.duration}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Level</h4>
                  <p className="mt-1 text-gray-900">{course.level}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-500">Price</h4>
                  <p className="mt-1 text-2xl font-bold text-purple-600">${course.price}</p>
                </div>
                <div className="pt-4 border-t border-gray-200">
                  <button className="w-full bg-purple-600 text-white px-4 py-3 rounded-md font-medium hover:bg-purple-700 transition-colors">
                    Enroll Now
                  </button>
                  <p className="mt-2 text-sm text-center text-gray-500">
                    Or contact us for group discounts
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-6 bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-gray-900">Have questions?</h3>
              <p className="mt-2 text-gray-600">
                Our education advisors are here to help you choose the right course.
              </p>
              <button className="mt-4 w-full bg-white border border-purple-600 text-purple-600 px-4 py-2 rounded-md font-medium hover:bg-purple-50 transition-colors">
                Contact Us
              </button>
            </div>
          </div>
        </div>

        <div className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900">You May Also Like</h2>
          <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {Object.values(courses)
              .filter(c => c.id !== course.id)
              .slice(0, 3)
              .map((relatedCourse) => (
                <div key={relatedCourse.id} className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
                  <div className="relative h-48 bg-gray-200">
                    <Image
                      src={relatedCourse.image}
                      alt={relatedCourse.title}
                      layout="fill"
                      className="object-cover"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold text-gray-900">{relatedCourse.title}</h3>
                    <p className="mt-2 text-gray-600 line-clamp-2">{relatedCourse.description}</p>
                    <div className="mt-4 flex items-center justify-between">
                      <span className="text-purple-600 font-medium">${relatedCourse.price}</span>
                      <Link href={`/courses/${relatedCourse.id}`} className="text-purple-600 hover:text-purple-800 font-medium">
                        Learn more →
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}
