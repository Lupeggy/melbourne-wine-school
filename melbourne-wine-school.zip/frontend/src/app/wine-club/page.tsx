import { Wine, Star, Gift, Award, Check, Users, Calendar, MapPin, Clock, Shield, ChevronRight, Percent, ChevronDown } from 'lucide-react';
import Link from 'next/link';
import MembershipCard from '@/components/marketplace/MembershipCard';
import { MembershipTier } from '@/types/membership';
import BenefitsGrid from '@/components/wine-club/BenefitsGrid';
import Testimonials from '@/components/wine-club/Testimonials';
import FAQ from '@/components/wine-club/FAQ';
import HowItWorks from '@/components/wine-club/HowItWorks';

// Mock data for membership tiers
const membershipTiers: MembershipTier[] = [
  {
    id: 'explorer',
    name: 'Explorer',
    price: 49,
    billingCycle: 'month',
    description: 'Perfect for those new to wine or looking to expand their palate with approachable, high-quality selections.',
    isPopular: false,
    features: [
      '2 bottles per month',
      '10% member discount',
      'Free shipping on orders over $150',
      'Access to virtual tastings',
      'Monthly tasting notes'
    ],
    discount: 0,
    bottleCredits: 2,
    freeShipping: false,
    exclusiveAccess: false
  },
  {
    id: 'connoisseur',
    name: 'Connoisseur',
    price: 99,
    billingCycle: 'month',
    description: 'For the wine enthusiast who appreciates premium selections and wants to explore diverse wine regions.',
    isPopular: true,
    features: [
      '4 bottles per month',
      '15% member discount',
      'Free shipping on all orders',
      'Access to exclusive virtual and in-person events',
      'Detailed tasting notes and food pairing suggestions',
      'Priority access to limited releases'
    ],
    discount: 0,
    bottleCredits: 4,
    freeShipping: true,
    exclusiveAccess: false
  },
  {
    id: 'collector',
    name: 'Collector',
    price: 199,
    billingCycle: 'month',
    description: 'For the serious collector seeking rare, allocated, and cellar-worthy wines from around the world.',
    isPopular: false,
    features: [
      '8 bottles per month',
      '20% member discount',
      'Free shipping on all orders',
      'VIP access to all events',
      'Personalized wine consultation',
      'Exclusive access to rare vintages',
      'Complimentary wine storage for 6 months',
      'Invitation to annual members-only gala'
    ],
    discount: 0,
    bottleCredits: 8,
    freeShipping: true,
    exclusiveAccess: true
  }
];

export default function WineClubPage() {
  return (
    <div className="bg-gray-50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-primary-700 to-primary-900 text-white py-20 md:py-32">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-40"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
        </div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">Melbourne Wine Club</h1>
          <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-8">
            Join our exclusive wine club and enjoy curated selections, member-only benefits, and expert-led tastings.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a 
              href="#membership" 
              className="bg-white text-primary-700 hover:bg-gray-100 px-8 py-4 rounded-md font-medium text-lg transition-colors"
            >
              Join Now
            </a>
            <a 
              href="#how-it-works" 
              className="border-2 border-white text-white hover:bg-white/10 px-8 py-4 rounded-md font-medium text-lg transition-colors"
            >
              How It Works
            </a>
          </div>
          <div className="mt-12">
            <a 
              href="#benefits" 
              className="inline-flex items-center text-white/80 hover:text-white transition-colors"
            >
              <span>Explore Benefits</span>
              <ChevronDown className="ml-2 h-5 w-5 animate-bounce" />
            </a>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <HowItWorks />

      {/* Membership Tiers */}
      <section id="membership" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Choose Your Membership</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Select the perfect wine club membership to suit your taste and lifestyle.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {membershipTiers.map((tier) => (
              <MembershipCard key={tier.id} tier={tier} />
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section id="benefits" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Member Benefits</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              As a Melbourne Wine Club member, you'll enjoy these exclusive benefits:
            </p>
          </div>
          <BenefitsGrid />
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">What Our Members Say</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Join thousands of satisfied wine lovers who have elevated their wine experience with us.
            </p>
          </div>
          <Testimonials />
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-gray-600">
              Everything you need to know about the Melbourne Wine Club.
            </p>
          </div>
          <FAQ />
          
          <div className="mt-12 text-center">
            <h3 className="text-xl font-medium text-gray-900 mb-4">Still have questions?</h3>
            <p className="text-gray-600 mb-6">Our wine experts are here to help you find the perfect membership.</p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <a 
                href="mailto:membership@melbournewineschool.com.au" 
                className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-3 rounded-md font-medium"
              >
                Contact Us
              </a>
              <a 
                href="tel:+61396541055" 
                className="border-2 border-primary-600 text-primary-600 hover:bg-primary-50 px-6 py-3 rounded-md font-medium"
              >
                Call (03) 9654 1055
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary-700 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Join the Club?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Become a member today and start enjoying exclusive benefits, curated wines, and unforgettable experiences.
          </p>
          <a 
            href="#membership" 
            className="inline-block bg-white text-primary-700 hover:bg-gray-100 px-8 py-3 rounded-md font-medium text-lg transition-colors"
          >
            Choose Your Membership
          </a>
        </div>
      </section>
    </div>
  );
}
