'use client';

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useRef, useEffect } from "react";
import { Menu, X, Phone, Mail, ShoppingCart, User } from 'lucide-react';

type NavItem = {
  name: string;
  href: string;
};

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const pathname = usePathname();
  const navRef = useRef<HTMLDivElement>(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (navRef.current && !navRef.current.contains(event.target as Node)) {
        setIsCartOpen(false);
        setIsProfileOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleCart = () => {
    setIsCartOpen(!isCartOpen);
    setIsProfileOpen(false);
  };

  const toggleProfile = () => {
    setIsProfileOpen(!isProfileOpen);
    setIsCartOpen(false);
  };

  const closeAll = () => {
    setIsOpen(false);
    setIsCartOpen(false);
    setIsProfileOpen(false);
  };

  const navItems: NavItem[] = [
    { name: "Home", href: "/" },
    { name: "WSET", href: "/courses/wset" },
    { name: "Other Courses", href: "/courses" },
    { name: "Wine Club", href: "/wine-club" },
    { name: "Marketplace", href: "/marketplace" },
    { name: "Events", href: "/events" },
    { name: "About", href: "/about" },
    { name: "Support", href: "/support" },
    { name: "Contact", href: "/contact" },
  ];

  const renderNavItem = (item: NavItem) => (
    <Link
      key={item.href}
      href={item.href}
      className={`px-3 py-2 text-sm font-medium ${
        pathname === item.href
          ? 'text-primary-600 border-b-2 border-primary-600'
          : 'text-gray-700 hover:text-primary-600 hover:border-b-2 hover:border-primary-600'
      }`}
      onClick={closeAll}
    >
      {item.name}
    </Link>
  );

  return (
    <div className="bg-white shadow-sm sticky top-0 z-50">
      <div ref={navRef}>
        {/* Top bar with contact info */}
        <div className="bg-primary-900 text-white text-sm">
          <div className="container mx-auto px-4 py-2">
            <div className="flex justify-between items-center">
              <div className="flex space-x-6">
                <a href="tel:+61396541055" className="flex items-center hover:text-primary-200 transition-colors">
                  <Phone className="h-3.5 w-3.5 mr-2" />
                  +61 3 9654 1055
                </a>
                <a href="mailto:info@melbournewineschool.com.au" className="flex items-center hover:text-primary-200 transition-colors">
                  <Mail className="h-3.5 w-3.5 mr-2" />
                  info@melbournewineschool.com.au
                </a>
              </div>
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <button 
                    onClick={toggleCart}
                    className="p-1.5 hover:bg-primary-800 rounded-full transition-colors relative"
                    aria-label="Shopping Cart"
                  >
                    <ShoppingCart className="h-4 w-4" />
                    <span className="absolute -top-1 -right-1 bg-white text-primary-900 text-xs font-bold rounded-full h-4 w-4 flex items-center justify-center">0</span>
                  </button>
                  {isCartOpen && (
                    <div className="absolute right-0 mt-2 w-72 bg-white rounded-md shadow-lg py-1 z-50">
                      <div className="px-4 py-3 border-b">
                        <p className="text-sm text-gray-700">Your cart is empty</p>
                      </div>
                      <div className="px-4 py-2">
                        <a href="/cart" className="block w-full text-center bg-primary-600 text-white px-4 py-2 rounded hover:bg-primary-700 transition-colors">
                          View Cart
                        </a>
                      </div>
                    </div>
                  )}
                </div>
                <div className="relative">
                  <button 
                    onClick={toggleProfile}
                    className="p-1.5 hover:bg-primary-800 rounded-full transition-colors"
                    aria-label="User Profile"
                  >
                    <User className="h-4 w-4" />
                  </button>
                  {isProfileOpen && (
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-50">
                      <a href="/login" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                        Login
                      </a>
                      <a href="/dashboard" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                        My Dashboard
                      </a>
                      <a href="/orders" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                        My Orders
                      </a>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main navigation */}
        <div className="bg-white">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center h-16">
              {/* Logo */}
              <div className="flex-shrink-0">
                <Link href="/" className="text-xl font-bold text-gray-900">
                  Melbourne Wine School
                </Link>
              </div>

              {/* Desktop Navigation */}
              <div className="hidden md:flex items-center space-x-1">
                {navItems.map((item) => (
                  <div key={item.name} className="relative">
                    <button
                      onClick={() => item.subItems ? toggleDropdown(item.name) : null}
                      className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                        pathname === item.href 
                          ? 'text-primary-700 bg-primary-50' 
                          : 'text-gray-700 hover:bg-gray-50 hover:text-primary-700'
                      } ${item.subItems ? 'flex items-center' : ''}`}
                    >
                      {item.name}
                      {item.subItems && (
                        <ChevronDown className={`ml-1 h-4 w-4 transition-transform ${
                          openDropdown === item.name ? 'transform rotate-180' : ''
                        }`} />
                      )}
                    </button>
                    {item.subItems && openDropdown === item.name && (
                      <div className="absolute left-0 mt-1 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50">
                        <div className="py-1">
                          {item.subItems.map((subItem) => (
                            <Link
                              key={subItem.name}
                              href={subItem.href}
                              className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-primary-700"
                              onClick={closeAll}
                            >
                              {subItem.name}
                            </Link>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              {/* Mobile menu button */}
              <div className="md:hidden flex items-center">
                <button
                  onClick={() => setIsOpen(!isOpen)}
                  className="inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-primary-600 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary-500"
                  aria-expanded="false"
                >
                  <span className="sr-only">Open main menu</span>
                  {isOpen ? (
                    <X className="block h-6 w-6" aria-hidden="true" />
                  ) : (
                    <Menu className="block h-6 w-6" aria-hidden="true" />
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Mobile menu */}
          {isOpen && (
            <div className="md:hidden bg-white border-t border-gray-200">
              <div className="px-2 pt-2 pb-3 space-y-1">
                {navItems.map((item) => (
                  <div key={item.name}>
                    <div className="flex items-center justify-between">
                      <Link
                        href={item.href}
                        onClick={closeAll}
                        className={`block px-3 py-2 rounded-md text-base font-medium ${
                          pathname === item.href
                            ? 'bg-gray-100 text-primary-700'
                            : 'text-gray-700 hover:bg-gray-50 hover:text-primary-700'
                        }`}
                      >
                        {item.name}
                      </Link>
                      {item.subItems && (
                        <button
                          onClick={() => toggleDropdown(item.name)}
                          className="p-2 text-gray-500 hover:text-gray-700"
                        >
                          <ChevronDown
                            className={`h-5 w-5 transform ${
                              openDropdown === item.name ? 'rotate-180' : ''
                            }`}
                            aria-hidden="true"
                          />
                        </button>
                      )}
                    </div>
                    {item.subItems && openDropdown === item.name && (
                      <div className="pl-4">
                        {item.subItems.map((subItem) => (
                          <Link
                            key={subItem.name}
                            href={subItem.href}
                            onClick={closeAll}
                            className="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-primary-700"
                          >
                            {subItem.name}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Navigation;
