'use client';

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, useRef, useEffect, FC } from "react";
import { Menu, X, ChevronDown, Phone, Mail, Wine } from 'lucide-react';

// Ensure React is in scope for JSX
export {};
declare global {
  namespace JSX {
    interface IntrinsicElements {
      div: React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>;
      button: React.DetailedHTMLProps<React.ButtonHTMLAttributes<HTMLButtonElement>, HTMLButtonElement>;
      a: React.DetailedHTMLProps<React.AnchorHTMLAttributes<HTMLAnchorElement>, HTMLAnchorElement>;
      span: React.DetailedHTMLProps<React.HTMLAttributes<HTMLSpanElement>, HTMLSpanElement>;
    }
  }
}

// Type for navigation items
type NavItem = {
  name: string;
  href: string;
  subItems?: { name: string; href: string }[];
};

// Type for the component props
type NavigationProps = {
  // Add any props if needed
};

const navItems: NavItem[] = [
  { name: "Home", href: "/" },
  { name: "About Us", href: "/about" },
  { 
    name: "Courses", 
    href: "/courses",
    subItems: [
      { name: "WSET Level 1", href: "/courses/wset-level-1" },
      { name: "WSET Level 2", href: "/courses/wset-level-2" },
      { name: "WSET Level 3", href: "/courses/wset-level-3" },
      { name: "Casual Classes", href: "/courses/casual" },
    ]
  },
  { 
    name: "Wine Club", 
    href: "/wine-club",
    subItems: [
      { name: "Membership Benefits", href: "/wine-club/benefits" },
      { name: "Events Calendar", href: "/wine-club/events" },
      { name: "Join Now", href: "/wine-club/join" },
    ]
  },
  { name: "Events", href: "/events" },
  { name: "Shop", href: "/shop" },
  { name: "Blog", href: "/blog" },
  { name: "Contact", href: "/contact" },
];

const Navigation: FC<NavigationProps> = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const pathname = usePathname();
  const navRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (navRef.current && !navRef.current.contains(event.target as Node)) {
        setOpenDropdown(null);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [navRef]);

  const toggleDropdown = (name: string) => {
    setOpenDropdown(openDropdown === name ? null : name);
  };

  const closeAll = () => {
    setIsOpen(false);
    setOpenDropdown(null);
  };

  return (
    <div className="bg-white">
      <div ref={navRef} className="w-full">
        {/* Top bar with contact info */}
        <div className="bg-primary-900 text-white text-sm">
          <div className="container mx-auto px-4 py-2">
            <div className="flex justify-between items-center">
              <div className="flex space-x-6">
                <a href="tel:+61396541055" className="flex items-center hover:text-primary-200 transition-colors">
                  <Phone className="h-3.5 w-3.5 mr-2" />
                  +61 3 9654 1055
                </a>
                <a href="mailto:info@melbournewineschool.com.au" className="flex items-center hover:text-primary-200 transition-colors">
                  <Mail className="h-3.5 w-3.5 mr-2" />
                  info@melbournewineschool.com.au
                </a>
              </div>
              <div className="flex items-center space-x-1">
                <Link href="/login" className="px-3 py-1.5 hover:bg-primary-800 rounded transition-colors">
                  Login
                </Link>
                <Link href="/signup" className="bg-primary-700 text-white px-4 py-1.5 rounded font-medium hover:bg-primary-800 transition-colors">
                  Sign Up
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Main navigation */}
        <div className="border-b">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center h-20">
              {/* Logo */}
              <div className="flex-shrink-0">
                <Link href="/" className="flex items-center">
                  <Wine className="h-9 w-9 text-primary-800" />
                  <span className="ml-2 text-2xl font-bold text-gray-900">Melbourne Wine School</span>
                </Link>
              </div>

              {/* Desktop Navigation */}
              <div className="hidden md:ml-10 md:flex md:space-x-8">
                {navItems.map((item) => (
                  <div key={item.name} className="relative group">
                    {item.subItems ? (
                      <>
                        <button
                          onClick={() => toggleDropdown(item.name)}
                          className="nav-link nav-link-primary flex items-center"
                        >
                          {item.name}
                          <ChevronDown className="ml-1 h-4 w-4" />
                        </button>
                        {openDropdown === item.name && (
                          <div className="dropdown-menu">
                            <div className="py-1">
                              {item.subItems.map((subItem) => (
                                <Link
                                  key={subItem.name}
                                  href={subItem.href}
                                  className="dropdown-item"
                                  onClick={() => setOpenDropdown(null)}
                                >
                                  {subItem.name}
                                </Link>
                              ))}
                            </div>
                          </div>
                        )}
                      </>
                    ) : (
                      <Link
                        href={item.href}
                        className={`nav-link ${
                          pathname === item.href ? 'nav-link-active' : 'nav-link-primary'
                        }`}
                      >
                        {item.name}
                      </Link>
                    )}
                  </div>
                ))}
              </div>

              {/* Mobile menu button */}
              <div className="md:hidden flex items-center">
                <button
                  onClick={() => setIsOpen(!isOpen)}
                  className="inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-primary-700 focus:outline-none transition-colors"
                  aria-expanded={isOpen}
                >
                  <span className="sr-only">Open main menu</span>
                  {isOpen ? (
                    <X className="h-6 w-6" />
                  ) : (
                    <Menu className="h-6 w-6" />
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {isOpen && (
          <div className="md:hidden">
            <div className="pt-2 pb-3 space-y-1 bg-white shadow-lg">
              {navItems.map((item) => (
                <div key={item.name} className="px-2">
                  {item.subItems ? (
                    <>
                      <button
                        onClick={() => toggleDropdown(item.name)}
                        className="w-full flex justify-between items-center px-4 py-3 text-base font-medium text-gray-700 hover:bg-gray-50 hover:text-primary-700 rounded-lg transition-colors"
                      >
                        {item.name}
                        <ChevronDown
                          className={`ml-2 h-4 w-4 transition-transform ${
                            openDropdown === item.name ? 'rotate-180' : ''
                          }`}
                        />
                      </button>
                      {openDropdown === item.name && (
                        <div className="pl-4 mt-1 space-y-1">
                          {item.subItems.map((subItem) => (
                            <Link
                              key={subItem.name}
                              href={subItem.href}
                              className="block pl-6 pr-4 py-2.5 text-base font-medium text-gray-600 hover:bg-gray-50 hover:text-primary-700 rounded-lg transition-colors"
                              onClick={() => {
                                setIsOpen(false);
                                setOpenDropdown(null);
                              }}
                            >
                              {subItem.name}
                            </Link>
                          ))}
                        </div>
                      )}
                    </>
                  ) : (
                    <Link
                      href={item.href}
                      className={`mobile-nav-item ${
                        pathname === item.href ? 'nav-link-active' : 'nav-link-primary'
                      }`}
                      onClick={() => {
                        setIsOpen(false);
                        setOpenDropdown(null);
                      }}
                    >
                      {item.name}
                    </Link>
                  )}
                </div>
              ))}
              <div className="pt-4 pb-4 border-t border-gray-200 mt-2 px-4 space-y-3">
                <a
                  href="#"
                  className="block w-full text-center px-4 py-2.5 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 hover:text-primary-700 text-base font-medium transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  Log in
                </a>
                <a
                  href="#"
                  className="block w-full text-center px-4 py-2.5 bg-primary-700 text-white rounded-lg text-base font-medium hover:bg-primary-800 transition-colors"
                  onClick={() => setIsOpen(false)}
                >
                  Sign up
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Navigation;
